# Spin the Wheel game
![Cloudflare](https://img.shields.io/badge/Cloudflare-F38020?style=for-the-badge&logoColor=white&label=Powered%20By)

This project utilises ReactJs best practices to build a spin the wheel like game 
![spinner](https://user-images.githubusercontent.com/77246158/206507735-f6674a7e-accb-4e29-8ce6-a9cb5bf58bd6.png)


### Made Using-
- Framework [ReactJS](https://reactjs.org/)
- Confetti [Confetti](https://github.com/Agezao/confetti-js)
- Deployed using [CloudFlare](https://pages.dev)

Hope you enjoy it!!!
